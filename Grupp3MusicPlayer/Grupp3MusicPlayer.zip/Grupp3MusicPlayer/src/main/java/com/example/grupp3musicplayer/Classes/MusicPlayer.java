package com.example.grupp3musicplayer.Classes;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.*;
import javafx.scene.media.MediaPlayer;
public class MusicPlayer {
    private MediaPlayer mediaPlayer;
    private Playlist playlistManager;
}
